const express=require('express');
const router=express.Router();
router.get('/home',(req,res)=>{
    res.render('partials/home');
})
router.get('/login',(req,res)=>{
    res.render('partials/login');
})
router.get('/espe',(req,res)=>{
    res.render('partials/espe');
})
router.get('/home/menu',(req,res)=>{
    res.render('partials/inicioAd');
})
router.get('/home/menuE',(req,res)=>{
    res.render('partials/inicioEL');
})
router.post('/login',(req,res)=>{
    const{user}=req.body;
    const{password}=req.body;
    console.log(user);
    if(user=="admin" && password=="admin"){
        res.redirect('/home/menu');
    }else if(user=="elogistica" && password=="elogistica"){
        res.redirect('/home/menuE');
    }
    else{
        res.redirect('/login');
    }
    
})
module.exports=router;


