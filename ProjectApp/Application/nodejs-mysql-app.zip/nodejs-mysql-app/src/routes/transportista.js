const express=require('express');
const router=express.Router();

const pool =require('../database');

router.get('/add',(req,res)=>{
    res.render('transportista/add');
})
router.get('/home',(req,res)=>{
    res.render('transportista/home');
})
router.post('/add',async (req,res)=>{
    console.log(req.body);
    const{codigotransp,ci, nombre, direccion, telfconvencional, telfcelular, correo, placaCamion,tipoCamion}=req.body;
    const newCarrier={
        codigotransp, ci, nombre, direccion, telfconvencional, telfcelular, correo, placaCamion,tipoCamion
    };
    await pool.query('INSERT INTO transportista set ?',[newCarrier]);
    res.redirect('/transportista');
})
router.get('/', (req,res)=>{
    res.render('transportista/home');
})
router.get('/search', async (req,res)=>{
    const transportista= await pool.query('SELECT * FROM transportista ');
    console.log(transportista);
    res.render('transportista/buscar',{transportista});
})
router.post('/search', async(req,res)=>{
    const{ci}=req.body;
    const transportista= await pool.query('SELECT * FROM transportista WHERE ci =?',ci);
    res.render('transportista/buscar',{transportista});
});
router.get('/delete', async (req,res)=>{
    const transportista= await pool.query('SELECT * FROM transportista ');
    res.render('transportista/eliminar',{transportista});
})
router.post('/delete', async(req,res)=>{
    const{ci}=req.body;
    console.log(ci);
        const transportista= await pool.query('DELETE FROM transportista WHERE ci =?',ci);
        res.render('transportista/home');
});
router.get('/update', async(req,res)=>{
    res.render('transportista/modificar');
})
router.post('/update', async(req,res)=>{
    const{nombre}=req.body;
    const{direccion}=req.body;
    const{telfconvencional}=req.body;
    const{telfcelular}=req.body;
    const{correo}=req.body;
    const{placaCamion}=req.body;
    const{tipoCamion}=req.body;
    const{ci}=req.body;
    const{cic}=req.body;
    const{btnmodificar}=req.body;
    console.log(btnmodificar); 
        if(btnmodificar==0)
        {
            console.log(ci); 
        const transportista= await pool.query('SELECT * FROM transportista WHERE ci =?',ci);
        res.render('transportista/modificar',{transportista}); 
        }
        if(btnmodificar==1)
        {
        console.log(cic); 
        await pool.query("UPDATE transportista SET ?,?,?,?,?,?,? WHERE ?" 
        ,[{ nombre: nombre },{ direccion: direccion },{ telfconvencional: telfconvencional },
            { telfcelular: telfcelular },{ correo: correo },{ placaCamion: placaCamion }, 
            { tipoCamion: tipoCamion },{ ci: cic }]);
        res.render('transportista/home'); 
        }
});

module.exports=router;