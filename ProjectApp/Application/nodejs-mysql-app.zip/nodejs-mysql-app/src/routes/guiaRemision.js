const express=require('express');
const router=express.Router();
const pool =require('../database');
var contador=0;
router.get('/add',async(req,res)=>{
        const cliente= await pool.query('SELECT * FROM cliente');
        const transportista= await pool.query('SELECT * FROM transportista');
        const zona= await pool.query('SELECT * FROM zona');
        const producto= await pool.query('SELECT * FROM producto');
        console.log(cliente);
        res.render('guia/addget',{cliente,transportista,zona,producto});

});
router.post('/add',async(req,res)=>{
    contador++;
    var numguia=contador;
    const {nombreprod1}=req.body;
    const {nombreprod2}=req.body;
    const {nombreprod3}=req.body;
    const {nombreprod4}=req.body;
    const {nombreprod5}=req.body;
    const {fechaenvio}=req.body;
    const {horaenvio}=req.body;
    const {fechallegada}=req.body;
    const {horallegada}=req.body;
    const {codigotransportista}=req.body;
    const {ciremit}=req.body;
    const {cidestin}=req.body;
    const {codigozonaenvio}=req.body;
    const {codigozonallegada}=req.body;
    const {estadoguia}=req.body;
    const {estadoentrega}=req.body;
    const iddet=numguia;
    const iddetalle=numguia;
    const iddetalle1=numguia;
    const iddetalle2=numguia;
    const iddetalle3=numguia;
    const iddetalle4=numguia;
    //const cantidad="";
    //const cantidad=await pool.query('SELECT count(codproducto) FROM detalleproducto WHERE iddetalle=?',numguia);
    //const tot=Object.values(JSON.parse(JSON.stringify(total)));
    const iva="";
    //const codproducto=await pool.query("SELECT codigoprod FROM producto WHERE nombreprod=?",nombreprod1);
    //const codigo=JSON.stringify(codproducto);
    //const codigo=Object.values(JSON.parse(codproducto));
    
    
    //await pool.query("INSERT INTO detalleproducto iddetalle,codproducto VALUES ('1', 'TEL01')");
    if(nombreprod1!="-")
    {
        await pool.query('INSERT INTO detalleproducto set ?,?',[{iddetalle:iddetalle},{codproducto:nombreprod1}]);
    }
    if(nombreprod2!="-")
    {
    await pool.query('INSERT INTO detalleproducto set ?,?',[{iddetalle:iddetalle1},{codproducto:nombreprod2}]);}
    if(nombreprod3!="-")
    {
    await pool.query('INSERT INTO detalleproducto set ?,?',[{iddetalle:iddetalle2},{codproducto:nombreprod3}]);}
    if(nombreprod4!="-")
    {
    await pool.query('INSERT INTO detalleproducto set ?,?',[{iddetalle:iddetalle3},{codproducto:nombreprod4}]);}
    if(nombreprod5!="-")
    {
    await pool.query('INSERT INTO detalleproducto set ?,?',[{iddetalle:iddetalle4},{codproducto:nombreprod5}]);}
    const totalF=await pool.query('select sum(valorunit) as totalF from detalleproducto d, producto p where p.codigoprod=d.codproducto and d.iddetalle like ?',numguia);
    const cantidad=await pool.query('SELECT count(codproducto) as cantidad FROM detalleproducto WHERE iddetalle=?',numguia);
    
    console.log(cantidad);
    await pool.query('INSERT INTO guia set ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?'
    ,[{numguia:numguia},{fechaenvio:fechaenvio},{horaenvio:horaenvio},{fechallegada:fechallegada},
    {horallegada:horallegada},{codtransport:codigotransportista},{ciclienteremit:ciremit},{ciclientedesti:cidestin},
    {codigozonenvio:codigozonaenvio},{codigozonallegada:codigozonallegada},{iddetalleprod:iddet},
    {estadoguia:estadoguia},{estadoentrega:estadoentrega},{cantidadprod:cantidad},{iva:iva},{valortotal:totalF}]);
    //res.render('guia/add',{cliente,transportista,zona,producto});
    const guia=await pool.query('SELECT * FROM guia WHERE numguia =?',numguia);
    const transportista= await pool.query('SELECT * FROM transportista WHERE codigotransp=?',codigotransportista);
    const clienter= await pool.query('SELECT * FROM cliente WHERE ci=?',ciremit);
    const cliented= await pool.query('SELECT * FROM cliente WHERE ci=?',cidestin);
    const zonae= await pool.query('SELECT * FROM zona WHERE codigozona=?',codigozonaenvio);
    const zonal= await pool.query('SELECT * FROM zona WHERE codigozona=?',codigozonallegada);
    const producto= await pool.query('select * from producto p, detalleproducto d where p.codigoprod=d.codproducto and d.iddetalle like ?',numguia);
    console.log(guia);
    res.render('guia/add',{guia,transportista,totalF,clienter,cliented,zonae,zonal,cantidad,producto});
});
module.exports=router;

