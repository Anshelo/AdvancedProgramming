const express=require('express');
const router=express.Router();

const pool =require('../database');

router.get('/add',(req,res)=>{
    res.render('zona/add');
})
router.get('/home',(req,res)=>{
    res.render('zona/home');
})
router.post('/add',async (req,res)=>{
    console.log(req.body);
    const{codigozona, nombrezona}=req.body;
    const newZone={
        codigozona, nombrezona
    };
    await pool.query('INSERT INTO zona set ?',[newZone]);
    res.redirect('/zona');
})
router.get('/search', async (req,res)=>{
    const zona= await pool.query('SELECT * FROM zona ');
    console.log(zona);
    res.render('zona/buscar',{zona});
})
router.post('/search', async(req,res)=>{
    const{codigozona}=req.body;
    const zona= await pool.query('SELECT * FROM zona WHERE codigozona =?',codigozona);
    res.render('zona/buscar',{zona});
});
router.get('/delete', async (req,res)=>{
    const zona= await pool.query('SELECT * FROM zona ');
    res.render('zona/eliminar',{zona});
})
router.post('/delete', async(req,res)=>{
    const{codigozona}=req.body;
    console.log(codigozona);
        const zona= await pool.query('DELETE FROM zona WHERE codigozona =?',codigozona);
        res.render('zona/home');
});
router.get('/update', async(req,res)=>{
    res.render('zona/modificar');
})
router.post('/update', async(req,res)=>{
    const{nombrezona}=req.body;
    const{codigozona}=req.body;
    const{codigozon}=req.body;
    const{btnmodificar}=req.body;
    console.log(btnmodificar); 
        if(btnmodificar==0)
        {
        const zona= await pool.query('SELECT * FROM zona WHERE codigozona =?',codigozona);
        res.render('zona/modificar',{zona}); 
        }
        if(btnmodificar==1)
        {
        console.log(codigozon); 
        await pool.query("UPDATE zona SET ? WHERE ?" ,[{ nombrezona: nombrezona }, { codigozona: codigozon }]);
        res.render('zona/home'); 
        }
});
router.get('/', (req,res)=>{
    res.render('zona/home');
})
module.exports=router;