const express=require('express');
const router=express.Router();

const pool =require('../database');
router.get('/home/menu',(req,res)=>{
    res.render('partials/inicioAd');
})

router.get('/add',(req,res)=>{
    res.render('cliente/add');
})

router.get('/home',(req,res)=>{
    res.render('cliente/home');
})

router.post('/add',async (req,res)=>{
    console.log(req.body);
    const{ci, ruc, nombre, direccion, telfconvencional, telfcelular, correo}=req.body;
    const newCustomer={
        ci, ruc, nombre, direccion, telfconvencional, telfcelular, correo
    };
    await pool.query('INSERT INTO cliente set ?',[newCustomer]);
    res.redirect('/cliente');
}) 
router.get('/', (req,res)=>{
    res.render('cliente/home');
});
router.get('/search', async (req,res)=>{
    const cliente= await pool.query('SELECT * FROM cliente ');
    console.log(cliente);
    res.render('cliente/buscar',{cliente});
})
router.post('/search', async(req,res)=>{
    const{ci}=req.body;
    const cliente= await pool.query('SELECT * FROM cliente WHERE ci =?',ci);
    res.render('cliente/buscar',{cliente});
});
router.get('/delete', async (req,res)=>{
    const cliente= await pool.query('SELECT * FROM cliente ');
    res.render('cliente/eliminar',{cliente});
})
router.post('/delete', async(req,res)=>{
    const{ci}=req.body;
    console.log(ci);
        const cliente= await pool.query('DELETE FROM cliente WHERE ci =?',ci);
        res.render('cliente/home');
});

router.get('/update', async(req,res)=>{
    res.render('cliente/modificar');
})
router.post('/update', async(req,res)=>{
    const{nombre}=req.body;
    const{direccion}=req.body;
    const{telfconvencional}=req.body;
    const{telfcelular}=req.body;
    const{correo}=req.body;
    const{ci}=req.body;
    const{cic}=req.body;
    const{btnmodificar}=req.body;
    console.log(btnmodificar); 
        if(btnmodificar==0)
        {
        const cliente= await pool.query('SELECT * FROM cliente WHERE ci =?',ci);
        res.render('cliente/modificar',{cliente}); 
        }
        if(btnmodificar==1)
        {
        console.log(cic); 
        await pool.query("UPDATE cliente SET ?,?,?,?,? WHERE ?" ,[{ nombre: nombre },{ direccion: direccion },{ telfconvencional: telfconvencional },{ telfcelular: telfcelular },{ correo: correo }, { ci: cic }]);
        res.render('cliente/home'); 
        }
});

module.exports=router;