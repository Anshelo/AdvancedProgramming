const express=require('express');
const router=express.Router();

const pool =require('../database');

router.get('/add',(req,res)=>{
    res.render('producto/add');
})
router.get('/home',(req,res)=>{
    res.render('producto/home');
})
router.post('/add',async (req,res)=>{
    console.log(req.body);
    const{codigoprod, nombreprod, descripcion, sensibilidad, valorunit}=req.body;
    const newProduct={
        codigoprod, nombreprod, descripcion, sensibilidad, valorunit
    };
    await pool.query('INSERT INTO producto set ?',[newProduct]);
    res.redirect('/producto');
})
router.get('/', (req,res)=>{
    res.render('producto/home');
})
router.get('/search', async(req,res)=>{
    const producto= await pool.query('SELECT * FROM producto ');
    console.log(producto);
    res.render('producto/buscar',{producto});
});
router.post('/search', async(req,res)=>{
    console.log(req.body);
    const{codigoprod}=req.body;
    const producto= await pool.query('SELECT * FROM producto WHERE codigoprod =?',codigoprod);
    res.render('producto/buscar',{producto});
});
router.get('/delete', async (req,res)=>{
    const producto= await pool.query('SELECT * FROM producto ');
    res.render('producto/eliminar',{producto});
})
router.post('/delete', async(req,res)=>{
    const{codigoprod}=req.body;
    console.log(codigoprod);
        const producto= await pool.query('DELETE FROM producto WHERE codigoprod =?',codigoprod);
        res.render('producto/home');
});

router.get('/update', async(req,res)=>{
    res.render('producto/modificar');
})
router.post('/update', async(req,res)=>{
    const{codigoprod}=req.body;
    const{nombreprod}=req.body;
    const{descripcion}=req.body;
    const{sensibilidad}=req.body;
    const{valorunit}=req.body;
    const{codigoprodu}=req.body;
    const{btnmodificar}=req.body;
    console.log(btnmodificar); 
        if(btnmodificar==0)
        {
        const producto= await pool.query('SELECT * FROM producto WHERE codigoprod =?',codigoprod);
        res.render('producto/modificar',{producto}); 
        }
        if(btnmodificar==1)
        {
        console.log(codigoprodu); 
        await pool.query("UPDATE producto SET ?,?,?,? WHERE ?" ,[{ nombreprod: nombreprod },{ descripcion: descripcion },{ sensibilidad: sensibilidad },{ valorunit: valorunit }, { codigoprod: codigoprodu }]);
        res.render('producto/home'); 
        }
});

module.exports=router;