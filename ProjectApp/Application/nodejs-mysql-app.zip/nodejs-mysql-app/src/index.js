const express= require('express');//inicializar express
const morgan=require('morgan');
const exphbs=require('express-handlebars');
const path=require('path');

//inicializacones
express();//devuelve objeto y almaceno en app que es la aplicacion
const app=express();

//settings confiaciones servidor express en que puerto va afuncionar
app.set('port',process.env.PORT || 4000);
app.set('views',path.join(__dirname,'views'));
app.engine('.hbs',exphbs({
    
    defaultLayout:'main',
    layoutsDir: path.join(app.get('views'),'layouts'),
    partialsDir: path.join(app.get('views'),'partials'),
    extname: '.hbs',
    helpers: require('./lib/handlebars')
    

}))
app.set('view engine','.hbs')
//Widdlemares cada que se envia peticion morgan muestra las peticiones
app.use(morgan('dev'));
app.use(express.urlencoded({extended: false}));
app.use(express.json());
//Global Variables
app.use((req,res,next)=>{
    next();
})
//Routes
app.use(require('./routes'));
app.use(require('./routes/authentication'));
app.use('/cliente',require('./routes/cliente'));
app.use('/producto',require('./routes/producto'));
app.use('/zona',require('./routes/zona'));
app.use('/transportista',require('./routes/transportista'));
app.use('/guia',require('./routes/guiaRemision'));
//Public ccs javascript imagenes
app.use(express.static(path.join(__dirname,'public')));
//Starting the server
app.listen(app.get('port'),()=>{
    console.log('Server on port',app.get('port'));
})
