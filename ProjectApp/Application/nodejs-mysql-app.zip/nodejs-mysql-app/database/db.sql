CREATE DATABASE database_transportes;
USE database_transportes;
--DATABASE USER
CREATE TABLE users(
    id INT(12) NOT NULL,
    username VARCHAR(16) NOT NULL,
    password VARCHAR(60) NOT NULL
);
ALTER TABLE users
ADD PRIMARY KEY (id);
ALTER TABLE users
MODIFY id INT(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1;
--DATABASE CLIENTES
CREATE TABLE cliente(
    ci VARCHAR(10) NOT NULL,
    ruc VARCHAR(15),
    nombre VARCHAR(72) NOT NULL,
    direccion VARCHAR(128) NOT NULL,
    telfconvencional VARCHAR(10),
    telfcelular VARCHAR(10),
    correo VARCHAR(10) 
);
ALTER TABLE cliente
ADD PRIMARY KEY (ci);
--DATABASE TRANSPORTISTAS
CREATE TABLE transportista(
    codigotransp INT(8) NOT NULL,
    ci VARCHAR(10) NOT NULL,
    nombre VARCHAR(72) NOT NULL,
    direccion VARCHAR(128) NOT NULL,
    telfconvencional VARCHAR(10) ,
    telfcelular VARCHAR(10),
    correo VARCHAR(10),
    placaCamion VARCHAR(8) NOT NULL,
    tipoCamion VARCHAR(16) NOT NULL
);
ALTER TABLE transportista
ADD PRIMARY KEY (codigotransp);
ALTER TABLE transportista
MODIFY codigotransp INT(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1;
--DATABASE PRODUCTO
CREATE TABLE producto(
    codigoprod VARCHAR(8) NOT NULL,
    nombreprod VARCHAR(52) NOT NULL,
    descripcion VARCHAR(72),
    sensibilidad VARCHAR(16) NOT NULL,
    valorunit FLOAT NOT NULL 
);
ALTER TABLE producto
ADD PRIMARY KEY (codigoprod);
--DATABASE ZONA
CREATE TABLE zona(
    codigozona VARCHAR(8) NOT NULL,
    nombrezona VARCHAR(52) NOT NULL 
);
ALTER TABLE zona
ADD PRIMARY KEY (codigozona);
    